import React from 'react'

export const Footer = () => {
  return (
    <footer className='container-fluid bg-dark text-light text-center' style={{position : 'relative', 
    top : '20vh', padding : '5px'}}>Copyright &copy; EDU</footer>
  )
}
